package com.example.pocket_plus

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
